post <- function(tree, ...) UseMethod("post")

