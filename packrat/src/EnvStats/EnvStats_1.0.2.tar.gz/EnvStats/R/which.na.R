which.na <-
function (x) 
(1:length(x))[is.na(x)]
