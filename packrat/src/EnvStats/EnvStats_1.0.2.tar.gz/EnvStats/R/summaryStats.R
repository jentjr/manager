summaryStats <-
function (object, ...) 
UseMethod("summaryStats")
