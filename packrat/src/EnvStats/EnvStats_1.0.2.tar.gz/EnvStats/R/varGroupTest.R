varGroupTest <-
function (object, ...) 
UseMethod("varGroupTest")
