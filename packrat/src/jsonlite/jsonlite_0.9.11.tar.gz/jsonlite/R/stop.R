stop <- function(..., call. = FALSE){
  base::stop(..., call. = FALSE)
}
