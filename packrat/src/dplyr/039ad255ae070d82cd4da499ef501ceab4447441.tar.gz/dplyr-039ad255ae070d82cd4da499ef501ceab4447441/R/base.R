#' @export
filter.numeric <- function(.data, ...) stats::filter(x = .data, ...)
