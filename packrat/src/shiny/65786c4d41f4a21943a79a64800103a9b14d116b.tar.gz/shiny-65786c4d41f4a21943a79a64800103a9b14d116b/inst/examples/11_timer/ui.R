shinyUI(fluidPage(
  textOutput("currentTime")
))